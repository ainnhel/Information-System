package ainnhel;

import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Read_CRUD extends CRUD_Var {
    static ArrayList<String> first_name_list = new ArrayList<>();
    static ArrayList<String> middle_name_list = new ArrayList<>();
    static ArrayList<String> last_name_list = new ArrayList<>();
    static ArrayList<String> student_full_name_list = new ArrayList<>();
    static ArrayList<String> student_age_list = new ArrayList<>();
    static ArrayList<String> student_gender_list = new ArrayList<>();
    static ArrayList<String> student_email_list = new ArrayList<>();
    static ArrayList<Integer> studentNo = new ArrayList<>();

    public static void viewEmailList() {
        try {
            BufferedReader readDatabase = new BufferedReader(new FileReader("student_email_database.txt"));
            System.out.println("student_email_database [online]");

            String line;
            while ((line = readDatabase.readLine()) != null) {
                student_email_list.add(line.trim());
            }
            readDatabase.close();
        } catch (IOException e) {
            System.out.println("student_email_database [offline]");
        }
    }

    public static void viewGenderList() {
        try {
            BufferedReader readDatabase = new BufferedReader(new FileReader("student_gender_database.txt"));
            System.out.println("student_gender_database [online]");

            String line;
            while ((line = readDatabase.readLine()) != null) {
                student_gender_list.add(line.trim());
            }
            readDatabase.close();
        } catch (IOException e) {
            System.out.println("student_gender_database [offline]");
        }
    }

    public static void viewAgeList() {
        try {
            BufferedReader readDatabase = new BufferedReader(new FileReader("student_age_database.txt"));
            System.out.println("student_age_database [online]");

            String line;
            while ((line = readDatabase.readLine()) != null) {
                student_age_list.add(line.trim());
            }
            readDatabase.close();
        } catch (IOException e) {
            System.out.println("student_age_database [offline]");
        }
    }

    public static void viewFullNameList() {
        try {
            readAndPopulateList("first_name_database.txt", first_name_list, "first_name_database [online]");
            readAndPopulateList("middle_name_database.txt", middle_name_list, "middle_name_database [online]");
            readAndPopulateList("last_name_database.txt", last_name_list, "last_name_database [online]");

            for (int x = 0; x < first_name_list.size(); x++) {
                String combine = first_name_list.get(x) + " " + middle_name_list.get(x) + " " + last_name_list.get(x);
                student_full_name_list.add(combine);
            }
        } catch (IOException e) {
            System.out.println("One or more name databases are offline");
        }
    }

    private static void readAndPopulateList(String fileName, ArrayList<String> list, String onlineMessage) throws IOException {
        BufferedReader readDatabase = new BufferedReader(new FileReader(fileName));
        System.out.println(onlineMessage);

        String line;
        while ((line = readDatabase.readLine()) != null) {
            list.add(line.trim());
        }
        readDatabase.close();
    }

    public static void viewAllData() {
        System.out.println("\n" + ">>>Student Database<<<" + "\n");

        for (int w = 0; w < student_full_name_list.size(); w++) {
            studentNo.add(w);
            System.out.println("Student No.: " + (studentNo.get(w) + 1));
            System.out.println("Full name: " + student_full_name_list.get(w));
            System.out.println("Age: " + student_age_list.get(w));
            System.out.println("Gender: " + student_gender_list.get(w));
            System.out.println("Email Address: " + student_email_list.get(w));
            System.out.println("------------------------------------------------");
        }
    }

}
