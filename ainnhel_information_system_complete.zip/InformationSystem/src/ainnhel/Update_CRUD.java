package ainnhel;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import java.io.BufferedWriter;
import java.io.FileWriter;

public class Update_CRUD extends Delete_CRUD {
    static Scanner scanner = new Scanner(System.in);

    public static void updateMenu() {
        System.out.println("Option");
        System.out.println("(A) Update Student Name");
        System.out.println("(B) Update Student Age");
        System.out.println("(C) Update Student Email");
        System.out.println("(D) Update Student Gender");
        System.out.println("(E) Exit");
    }

    public static void replaceLine(String fileName, int lineNum, String text) throws IOException {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(fileName));
            String[] lines = reader.lines().toArray(String[]::new);
            reader.close();

            // Check if lineNum is within the range of lines
            if(lineNum >= 0 && lineNum < lines.length) {
                lines[lineNum] = text; // Replace the specified line with the new text
            }

            BufferedWriter writer = new BufferedWriter(new FileWriter(fileName)); // Write back to the original file

            for(String line : lines) {
                writer.write(line);
                writer.newLine(); // Add a new line after each line
            }

            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void updateName() throws IOException {
        String invalidStudentNoCharacter = "[^0-9]";

        while (start == 1) {
            System.out.println("Select a student number to update");
            try {
                int maximumStudentNumber = student_full_name_list.size();
                int selectStudentNo = Integer.parseInt(scanner.nextLine());

                if (selectStudentNo > maximumStudentNumber) {
                    System.out.println("Student Number not found!");
                    Create_CRUD.exception();
                    updateName();
                } else if (selectStudentNo >= 1 && selectStudentNo <= 10) {
                    // First name
                    while (start == 1) {
                        System.out.println("Enter First Name: ");
                        String updateFirstName = scanner.nextLine();

                        if (updateFirstName.matches(invalid_name_character)) {
                            System.out.println("Only alphanumeric characters are allowed, numbers are not allowed");
                            Create_CRUD.exception();
                        } else if (updateFirstName.isEmpty()) {
                            System.out.println("Empty input detected");
                            Create_CRUD.exception();
                        } else {
                            replaceLine("first_name_database.txt", selectStudentNo - 1, updateFirstName);
                            System.out.println("Updated Successfully");
                            break;
                        }
                    }

                    // Middle name
                    while (start == 1) {
                        System.out.println("Enter Middle Name: ");
                        String updateMiddleName = scanner.nextLine();

                        if (updateMiddleName.matches(invalid_name_character)) {
                            System.out.println("Only alphanumeric characters are allowed, numbers are not allowed");
                            Create_CRUD.exception();
                        } else if (updateMiddleName.isEmpty()) {
                            System.out.println("Empty input detected");
                            Create_CRUD.exception();
                        } else {
                            replaceLine("middle_name_database.txt", selectStudentNo - 1, updateMiddleName);
                            System.out.println("Updated Successfully");
                            break;
                        }
                    }

                    // Last name
                    while (start == 1) {
                        System.out.println("Enter Last Name: ");
                        String updateLastName = scanner.nextLine();

                        if (updateLastName.matches(invalid_name_character)) {
                            System.out.println("Only alphanumeric characters are allowed, numbers are not allowed");
                            Create_CRUD.exception();
                        } else if (updateLastName.isEmpty()) {
                            System.out.println("Empty input detected");
                            Create_CRUD.exception();
                        } else {
                            replaceLine("last_name_database.txt", selectStudentNo - 1, updateLastName);
                            System.out.println("Updated Successfully");
                            break;
                        }
                    }
                }
            } catch (NumberFormatException e) {
                System.out.println("Numbers are only allowed");
                Create_CRUD.exception();
                updateName();
            }
            break;
        }
    }

    public static void ageUpdate() throws IOException {
        String invalidStudentNoCharacter = "[^0-9]";

        while (start == 1) {
            System.out.println("Select a student number to update");
            try {
                int maximumStudentNumber = student_full_name_list.size();
                int selectStudentNo = Integer.parseInt(scanner.nextLine());

                if (selectStudentNo > maximumStudentNumber) {
                    System.out.println("Student Number not found!");
                    Create_CRUD.exception();
                    ageUpdate();
                } else if (selectStudentNo >= 1 && selectStudentNo <= 10) {
                    // Age
                    while (start == 1) {
                        System.out.println("Enter your Age");
                        String updateAge = scanner.nextLine();

                        if (updateAge.matches("[^0-9]")) {
                            System.out.println("Only numbers are allowed!");
                            Create_CRUD.exception();
                        } else if (updateAge.isEmpty()) {
                            System.out.println("Empty input detected");
                            Create_CRUD.exception();
                        } else {
                            replaceLine("student_age_database.txt", selectStudentNo - 1, updateAge);
                            System.out.println("Updated Successfully");
                            break;
                        }
                    }
                }
            } catch (NumberFormatException e) {
                System.out.println("Numbers are only allowed");
                Create_CRUD.exception();
                ageUpdate();
            }
            break;
        }
    }

    public static void emailUpdate() throws IOException {
        String invalidStudentNoCharacter = "[^0-9]";

        while (start == 1) {
            System.out.println("Select a student number to update");
            try {
                int maximumStudentNumber = student_full_name_list.size();
                int selectStudentNo = Integer.parseInt(scanner.nextLine());

                if (selectStudentNo > maximumStudentNumber) {
                    System.out.println("Student Number not found!");
                    Create_CRUD.exception();
                    emailUpdate();
                } else if (selectStudentNo >= 1 && selectStudentNo <= 10) {
                    // Email Address
                    while (start == 1) {
                        System.out.println("Enter your Email Address");
                        String updateStudentEmail = scanner.nextLine();

                        if (updateStudentEmail.matches("[^a-zA-Z0-9@.]")) {
                            System.out.println("Not allowed characters are found!");
                            Create_CRUD.exception();
                        } else if (updateStudentEmail.isEmpty()) {
                            System.out.println("Empty input detected");
                            Create_CRUD.exception();
                        } else {
                            replaceLine("student_email_database.txt", selectStudentNo - 1, updateStudentEmail);
                            System.out.println("Updated Successfully");
                            break;
                        }
                    }
                }
            } catch (NumberFormatException e) {
                System.out.println("Numbers are only allowed");
                Create_CRUD.exception();
                emailUpdate();
            }
            break;
        }
    }

    public static void updateGender() throws IOException {
        String invalidStudentNoCharacter = "[^0-9]";

        while (start == 1) {
            System.out.println("Select a student number to update");
            try {
                int maximumStudentNumber = student_full_name_list.size();
                int selectStudentNo = Integer.parseInt(scanner.nextLine());

                if (selectStudentNo > maximumStudentNumber) {
                    System.out.println("Student Number not found!");
                    Create_CRUD.exception();
                    updateGender();
                } else if (selectStudentNo >= 1 && selectStudentNo <= 10) {
                    // Gender
                    while (start == 1) {
                        System.out.println("Enter your gender");
                        System.out.println("Select (M) Male (F) Female");
                        String updateStudentGender = scanner.nextLine();

                        if (updateStudentGender.matches("[^MmFf]")) {
                            System.out.println("Invalid option! please select (M)Male (F)Female");
                            Create_CRUD.exception();
                        } else if (updateStudentGender.isEmpty()) {
                            System.out.println("Empty input detected");
                            Create_CRUD.exception();
                        } else {
                            String updatedGender = updateStudentGender.equals("M") || updateStudentGender.equals("m") ? "Male" : "Female";
                            replaceLine("student_gender_database.txt", selectStudentNo - 1, updatedGender);
                            System.out.println("Updated Successfully");
                            break;
                        }
                    }
                }
            } catch (NumberFormatException e) {
                System.out.println("Numbers are only allowed");
                Create_CRUD.exception();
                updateGender();
            }
            break;
        }
    }

    public static void studentListOption() {
        System.out.println("Checking student database...");
        Read_CRUD.viewFullNameList();
        Read_CRUD.viewAgeList();
        Read_CRUD.viewEmailList();
        Read_CRUD.viewGenderList();

        System.out.println("No.\tStudent");
        int num = 0;
        for (String n : student_full_name_list) {
            num++;
            System.out.println("[" + num + "] " + n);
        }
        
    }

    public static void mainUpdateFunction() throws IOException {
        while (start == 1) {
            String invalidUpdateOption = "[^AaBbCcDdEe]";
            System.out.println("Select an option: ");
            String updateInputOption = scanner.nextLine();

            if (updateInputOption.matches(invalidUpdateOption)) {
                System.out.println("Invalid Option! please select (A)(B)(C)(D)");
                mainUpdateFunction();
            } else if (updateInputOption.isEmpty()) {
                System.out.println("Empty input detected!");
                Create_CRUD.exception();
                mainUpdateFunction();
            } else {
                // Name Update
                if (updateInputOption.equalsIgnoreCase("A")) {
                    System.out.println("Update Student Name Selected: ");
                    studentListOption();
                    updateName();
                }
                // Age Update
                else if (updateInputOption.equalsIgnoreCase("B")) {
                    System.out.println("Update Student Age Selected: ");
                    studentListOption();
                    ageUpdate();
                }
                // Email Update
                else if (updateInputOption.equalsIgnoreCase("C")) {
                    System.out.println("Update Student Email Selected: ");
                    studentListOption();
                    emailUpdate();
                }
                // Gender Update
                else if (updateInputOption.equalsIgnoreCase("D")) {
                    System.out.println("Update Student Gender Selected: ");
                    studentListOption();
                    updateGender();
                }
                // Exit
                else if (updateInputOption.equalsIgnoreCase("E")) {
                    System.out.println("Exit");
                    System.exit(1);
                }
                break;
            }
        }
    }
}
