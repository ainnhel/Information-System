package ainnhel;

import java.util.Scanner;
import java.util.regex.Pattern;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;

public class Create_CRUD extends Update_CRUD  {
	static Scanner scanner = new Scanner(System.in);
    static int start = 1;

    static String invalid_name_character = "[^a-zA-Z]";
    static String invalid_Age_character = "[^0-9]";
    static String invalid_gender_character = "[^MmFf]";
    static String invalid_email_character = "[^a-zA-Z0-9@.]";

    public static void exception() {
        System.out.println("Try Again");
    }

    public static void menu_option() {
        System.out.println("C.R.U.D Student Enrolment System");
        System.out.println("Note: our system is not case sensitive");
        System.out.println("Option:");
        System.out.println("(A) Create");
        System.out.println("(B) Read");
        System.out.println("(C) Update");
        System.out.println("(D) Delete");
        System.out.println("(E) Exit");
    }

    public static void firstName() {

        while (start == 1) {
            System.out.println("Enter your first name");
            String first_name_input = scanner.next();

            if (Pattern.compile(invalid_name_character).matcher(first_name_input).find()) {
                System.out.println("Only alphanumeric characters are allowed, numbers are not allowed");
                exception();
            } else if (first_name_input.equals("")) {
                System.out.println("Empty input detected");
                exception();
            } else {
                try {
                    FileWriter database = new FileWriter("first_name_database.txt", true);
                    database.write(first_name_input + "\n");
                    database.close();
                    System.out.println("You added successfully");
                } catch (IOException e) {
                    e.printStackTrace();
                }
                break;
            }
        }
    }
    
    public static void middleName() {
        int start = 1;

        while (start == 1) {
            System.out.println("Enter your middle name");
            String middleNameInput = scanner.next();

            if (Pattern.matches(invalid_name_character, middleNameInput)) {
                System.out.println("Only alphanumeric characters are allowed, numbers are not allowed");
                // handle exception here
            } else if (middleNameInput.equals("")) {
                System.out.println("Empty input detected!");
                // handle exception here
            } else {
                try (FileWriter database = new FileWriter("middle_name_database.txt", true)) {
                    database.write(middleNameInput + "\n");
                    System.out.println("You added successfully");
                    break;
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public static void lastName() {
    	int start = 1;
        while (start == 1) {
            System.out.println("Enter your last name");
            String lastNameInput = scanner.next();

            if (Pattern.matches("[^a-zA-Z]", lastNameInput)) {
                System.out.println("Only alphanumeric characters are allowed, numbers are not allowed");
                // Call to exception method in Create_CRUD class
                 Create_CRUD.exception();
            } else if (lastNameInput.isEmpty()) {
                System.out.println("Empty input detected!");
                // Call to exception method in Create_CRUD class
                 Create_CRUD.exception();
            } else {
                try {
                    FileWriter database = new FileWriter("last_name_database.txt", true);
                    database.write(lastNameInput + "\n");
                    database.close();
                    System.out.println("You added successfully");
                    break;
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    
    public static void studentAge() {
    	int start = 1;
        while (start == 1) {
            System.out.println("Enter your Age");
            String studentAgeInput = scanner.next();

            if (Pattern.matches("[^0-9]", studentAgeInput)) {
                System.out.println("Only numbers are allowed!");
                // Call to exception method in Create_CRUD class
                 Create_CRUD.exception();
            } else if (studentAgeInput.isEmpty()) {
                System.out.println("Empty input detected!");
                // Call to exception method in Create_CRUD class
                 Create_CRUD.exception();
            } else {
                try {
                    FileWriter database = new FileWriter("student_age_database.txt", true);
                    database.write(studentAgeInput + "\n");
                    database.close();
                    System.out.println("You added successfully");
                    break;
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    
    public static void studentGender() {
    	int start = 1;
        while (start == 1) {
            System.out.println("Enter your gender");
            System.out.println("Select (M) Male (F) Female");
            String studentGenderInput = scanner.next();

            if (Pattern.matches("[^MmFf]", studentGenderInput)) {
                System.out.println("Invalid option! Please select (M)(F)");
                // Call to exception method in Create_CRUD class
                 Create_CRUD.exception();
            } else if (studentGenderInput.isEmpty()) {
                System.out.println("Empty input detected!");
                // Call to exception method in Create_CRUD class
                 Create_CRUD.exception();
            } else if (studentGenderInput.equalsIgnoreCase("M")) {
                String conventionM = "Male";
                try {
                    FileWriter database = new FileWriter("student_gender_database.txt", true);
                    database.write(conventionM + "\n");
                    database.close();
                    System.out.println("You added successfully");
                    break;
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else if (studentGenderInput.equalsIgnoreCase("F")) {
                String conventionF = "Female";
                try {
                    FileWriter database = new FileWriter("student_gender_database.txt", true);
                    database.write(conventionF + "\n");
                    database.close();
                    System.out.println("You added successfully");
                    break;
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    
    public static void studentEmail() {
    	int start = 1;
        while (start == 1) {
            System.out.println("Enter your Email Address");
            String studentEmailInput = scanner.next();

            if (Pattern.matches("[^a-zA-Z0-9@.]", studentEmailInput)) {
                System.out.println("Not allowed character are found!");
                // Call to exception method in Create_CRUD class
                 Create_CRUD.exception();
            } else if (studentEmailInput.isEmpty()) {
                System.out.println("Empty input detected!");
                // Call to exception method in Create_CRUD class
                 Create_CRUD.exception();
            } else {
                try {
                    FileWriter database = new FileWriter("student_email_database.txt", true);
                    database.write(studentEmailInput + "\n");
                    database.close();
                    System.out.println("You added successfully");
                    break;
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    

    public static void mainCreateFunction() {
        int max_limit = 10;
        int current_size = 0;

        try {
            BufferedReader readDatabase = new BufferedReader(new FileReader("first_name_database.txt"));
            String line;
            while ((line = readDatabase.readLine()) != null) {
                current_size++;
            }
            readDatabase.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("Database storage limit is " + max_limit);
        System.out.println("Current storage size: " + current_size);
        System.out.println("\n");

        while (current_size < max_limit) {
            firstName();
            middleName();
            lastName();
            studentAge();
            studentGender();
            studentEmail();
            current_size++;
            break;
        }

        String invalid_back_option = "[^0]";
        
        while (start == 1) {
            System.out.println("Press (0) exit");
            String input_back = scanner.next();
            if (Pattern.compile(invalid_back_option).matcher(input_back).find()) {
                System.out.println("Invalid Option!");
                exception();
            } else if (input_back.equals("")) {
                System.out.println("Empty input detected!");
                exception();
            } else if (input_back.equals("0")) {
                System.out.println("Exit");
                System.exit(1);
            }
        }
    }//end of Create main


}
