package ainnhel;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Delete_CRUD extends CRUD_Var {
    static Scanner scanner = new Scanner(System.in);



    public static void deleteMenu() {
        Update_CRUD.studentListOption();
    }

    public static void deleteFirstName(int index) throws IOException {
        System.out.println("Deleting First Name");

        BufferedReader reader = new BufferedReader(new FileReader("first_name_database.txt"));
        String[] data = reader.lines().toArray(String[]::new);
        reader.close();

        System.arraycopy(data, index + 1, data, index, data.length - 1 - index);
        data[data.length - 1] = null;

        FileWriter writer = new FileWriter("first_name_database.txt");
        for (String n : data) {
            if (n != null) {
                writer.write(n + "\n");
            }
        }
        writer.close();
    }

    public static void deleteMiddleName(int index) throws IOException {
        System.out.println("Deleting Middle Name");

        BufferedReader reader = new BufferedReader(new FileReader("middle_name_database.txt"));
        String[] data = reader.lines().toArray(String[]::new);
        reader.close();

        System.arraycopy(data, index + 1, data, index, data.length - 1 - index);
        data[data.length - 1] = null;

        FileWriter writer = new FileWriter("middle_name_database.txt");
        for (String n : data) {
            if (n != null) {
                writer.write(n + "\n");
            }
        }
        writer.close();
    }

    public static void deleteLastName(int index) throws IOException {
        System.out.println("Deleting Last Name");

        BufferedReader reader = new BufferedReader(new FileReader("last_name_database.txt"));
        String[] data = reader.lines().toArray(String[]::new);
        reader.close();

        System.arraycopy(data, index + 1, data, index, data.length - 1 - index);
        data[data.length - 1] = null;

        FileWriter writer = new FileWriter("last_name_database.txt");
        for (String n : data) {
            if (n != null) {
                writer.write(n + "\n");
            }
        }
        writer.close();
    }

    public static void deleteAge(int index) throws IOException {
        System.out.println("Deleting Age");

        BufferedReader reader = new BufferedReader(new FileReader("student_age_database.txt"));
        String[] data = reader.lines().toArray(String[]::new);
        reader.close();

        System.arraycopy(data, index + 1, data, index, data.length - 1 - index);
        data[data.length - 1] = null;

        FileWriter writer = new FileWriter("student_age_database.txt");
        for (String n : data) {
            if (n != null) {
                writer.write(n + "\n");
            }
        }
        writer.close();
    }

    public static void deleteEmail(int index) throws IOException {
        System.out.println("Deleting Email");

        BufferedReader reader = new BufferedReader(new FileReader("student_email_database.txt"));
        String[] data = reader.lines().toArray(String[]::new);
        reader.close();

        System.arraycopy(data, index + 1, data, index, data.length - 1 - index);
        data[data.length - 1] = null;

        FileWriter writer = new FileWriter("student_email_database.txt");
        for (String n : data) {
            if (n != null) {
                writer.write(n + "\n");
            }
        }
        writer.close();
    }

    public static void deleteGender(int index) throws IOException {
        System.out.println("Deleting Gender");

        BufferedReader reader = new BufferedReader(new FileReader("student_gender_database.txt"));
        String[] data = reader.lines().toArray(String[]::new);
        reader.close();

        System.arraycopy(data, index + 1, data, index, data.length - 1 - index);
        data[data.length - 1] = null;

        FileWriter writer = new FileWriter("student_gender_database.txt");
        for (String n : data) {
            if (n != null) {
                writer.write(n + "\n");
            }
        }
        writer.close();
    }

    public static void mainDeleteFunction() throws IOException {
        String invalidStudentNoCharacter = "[^0-9]";

        while (start == 1) {
            System.out.println("Select the student number to delete");

            try {
                int maximumStudentNumber = student_full_name_list.size();

                int selectStudentNo = Integer.parseInt(scanner.nextLine());

                if (selectStudentNo > maximumStudentNumber) {
                    System.out.println("Student Number not found!");
                    Create_CRUD.exception();
                    mainDeleteFunction();
                } else if (selectStudentNo >= 1 && selectStudentNo <= 10) {
                    deleteFirstName(selectStudentNo - 1);
                    deleteMiddleName(selectStudentNo - 1);
                    deleteLastName(selectStudentNo - 1);
                    deleteAge(selectStudentNo - 1);
                    deleteEmail(selectStudentNo - 1);
                    deleteGender(selectStudentNo - 1);
                }
            } catch (NumberFormatException e) {
                System.out.println("Numbers are only allowed");
                Create_CRUD.exception();
                mainDeleteFunction();
            }
            break;
        }
    }
}
