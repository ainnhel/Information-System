package ainnhel;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.*;

public class Ainnhel_System extends Create_CRUD {
	
	//variables
	static ArrayList<String> first_name_list = new ArrayList<>();
    static ArrayList<String> middle_name_list = new ArrayList<>();
    static ArrayList<String> last_name_list = new ArrayList<>();

    static ArrayList<String> student_full_name_list = new ArrayList<>();
    static ArrayList<String> student_age_list = new ArrayList<>();
    static ArrayList<String> student_gender_list = new ArrayList<>();
    static ArrayList<String> student_email_list = new ArrayList<>();
    static ArrayList<Integer> studentNo = new ArrayList<>();

    // Exception
    static String invalid_main_option = "[^aABbCcDdEe]";
    static String invalid_character = "^\\s+[^0-9a-zA-Z-]+";
    static String invalid_name_character = "[^a-zA-Z-]+";
    static int start = 1;
	
	static Scanner scanner = new Scanner(System.in);
    static String invalid_option_character = "[^012]";

    public static void backFunction() {
        String invalid_back_option = "[^0]";

        while (start == 1) {
            System.out.println("Press (0) exit");
            String input_back = scanner.nextLine();
            if (Pattern.compile(invalid_back_option).matcher(input_back).find()) {
                System.out.println("Invalid Option!");
                Create_CRUD.exception();
            } else if (input_back.equals("")) {
                System.out.println("Empty input detected!");
                Create_CRUD.exception();
            } else if (input_back.equals("0")) {
                System.out.println("exit");
                System.exit(1);
            }
        }
    }

    public static void mainFunction() throws IOException {
        Create_CRUD.menu_option();

        while (start == 1) {
            System.out.println("Select an option: ");
            String option_input = scanner.nextLine();

            if (option_input.equals("A") || option_input.equals("a")) {
                System.out.println("Create Option: ");
                System.out.println("(2) Add Student");
                System.out.println("(1) Back");
                System.out.println("(0) Exit");

                while (start == 1) {
                    System.out.println("Select an option");
                    String add_option_input = scanner.nextLine();

                    if (add_option_input.equals("0")) {
                        System.out.println("Exit");
                        System.exit(1);
                    } else if (add_option_input.equals("1")) {
                        System.out.println("back");
                        System.out.println("\n");
                        mainFunction();
                    } else if (add_option_input.equals("2")) {
                        System.out.println("Add Student");
                        Create_CRUD.mainCreateFunction();
                    } else if (add_option_input.equals("")) {
                        System.out.println("Empty input detected!");
                        Create_CRUD.exception();
                    } else if (Pattern.compile(invalid_option_character).matcher(add_option_input).find()) {
                        System.out.println("Invalid option!");
                        Create_CRUD.exception();
                    }
                }
            } else if (option_input.equals("B") || option_input.equals("b")) {
                System.out.println("Read Option: ");
                System.out.println("(2) View Student");
                System.out.println("(1) Back");
                System.out.println("(0) Exit");

                while (start == 1) {
                    System.out.println("Select an option");
                    String read_option_input = scanner.nextLine();

                    if (read_option_input.equals("0")) {
                        System.out.println("Exit");
                        System.exit(1);
                    } else if (read_option_input.equals("1")) {
                        System.out.println("back");
                        System.out.println("\n");
                        mainFunction();
                    } else if (read_option_input.equals("2")) {
                        System.out.println("View Student Selected" + "\n");
                        System.out.println("Database Status:");
                        Read_CRUD.viewFullNameList();
                        Read_CRUD.viewAgeList();
                        Read_CRUD.viewGenderList();
                        Read_CRUD.viewEmailList();

                        Read_CRUD.viewAllData();
                        backFunction();
                    } else if (read_option_input.equals("")) {
                        System.out.println("Empty input detected!");
                        Create_CRUD.exception();
                    } else if (Pattern.compile(invalid_option_character).matcher(read_option_input).find()) {
                        System.out.println("Invalid option!");
                        Create_CRUD.exception();
                    }
                }
            } else if (option_input.equals("C") || option_input.equals("c")) {
                System.out.println("Update Option: ");
                System.out.println("(2) Update Student");
                System.out.println("(1) Back");
                System.out.println("(0) Exit");

                while (start == 1) {
                    System.out.println("Select an option");
                    String update_option_input = scanner.nextLine();

                    if (update_option_input.equals("0")) {
                        System.out.println("Exit");
                        System.exit(1);
                    } else if (update_option_input.equals("1")) {
                        System.out.println("back");
                        System.out.println("\n");
                        mainFunction();
                    } else if (update_option_input.equals("2")) {
                        System.out.println("Update Student");
                        Update_CRUD.updateMenu();
                        Update_CRUD.mainUpdateFunction();
                        backFunction();
                    } else if (update_option_input.equals("")) {
                        System.out.println("Empty input detected!");
                        Create_CRUD.exception();
                    } else if (Pattern.compile(invalid_option_character).matcher(update_option_input).find()) {
                        System.out.println("Invalid option!");
                        Create_CRUD.exception();
                    }
                }
            } else if (option_input.equals("D") || option_input.equals("d")) {
                System.out.println("Delete Selected");
                System.out.println("(2) Delete Student");
                System.out.println("(1) Back");
                System.out.println("(0) Exit");

                while (start == 1) {
                    System.out.println("Select an option");
                    String delete_option_input = scanner.nextLine();

                    if (delete_option_input.equals("0")) {
                        System.out.println("Exit");
                        System.exit(1);
                    } else if (delete_option_input.equals("1")) {
                        System.out.println("back");
                        System.out.println("\n");
                        mainFunction();
                    } else if (delete_option_input.equals("2")) {
                        System.out.println("Delete Student");
                        Delete_CRUD.deleteMenu();
                        Delete_CRUD.mainDeleteFunction();
                        backFunction();
                    } else if (delete_option_input.equals("")) {
                        System.out.println("Empty input detected!");
                        Create_CRUD.exception();
                    } else if (Pattern.compile(invalid_option_character).matcher(delete_option_input).find()) {
                        System.out.println("Invalid option!");
                        Create_CRUD.exception();
                    }
                }
            } else if (option_input.equals("E") || option_input.equals("e")) {
                System.out.println("Exit");
                System.exit(1);
            } else if (Pattern.compile(invalid_main_option).matcher(option_input).find()) {
                System.out.println("invalid option!");
                Create_CRUD.exception();
            } else if (option_input.equals("")) {
                System.out.println("Empty input detected!");
                Create_CRUD.exception();
            } else {
                System.out.println("there's a bug");
            }
        }
    }

    public static void main(String[] args) {
        try {
			mainFunction();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}
