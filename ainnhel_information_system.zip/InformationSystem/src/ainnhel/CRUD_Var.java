package ainnhel;

import java.util.ArrayList;

public class CRUD_Var {
    static ArrayList<String> first_name_list = new ArrayList<>();
    static ArrayList<String> middle_name_list = new ArrayList<>();
    static ArrayList<String> last_name_list = new ArrayList<>();

    static ArrayList<String> student_full_name_list = new ArrayList<>();
    static ArrayList<String> student_age_list = new ArrayList<>();
    static ArrayList<String> student_gender_list = new ArrayList<>();
    static ArrayList<String> student_email_list = new ArrayList<>();
    static ArrayList<Integer> studentNo = new ArrayList<>();

    // Exception
    static String invalid_main_option = "[^aABbCcDdEe]";
    static String invalid_character = "^\\s+[^0-9a-zA-Z-]+";
    static String invalid_name_character = "[^a-zA-Z-]+";
    static int start = 1;
}
