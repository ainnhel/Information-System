package ainnhel;

import java.util.Scanner;
import java.util.regex.Pattern;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;

public class Create_CRUD  {
    static int start = 1;

    static String invalid_name_character = "[^a-zA-Z]";
    static String invalid_Age_character = "[^0-9]";
    static String invalid_gender_character = "[^MmFf]";
    static String invalid_email_character = "[^a-zA-Z0-9@.]";

    public static void exception() {
        System.out.println("Try Again");
    }

    public static void menu_option() {
        System.out.println("C.R.U.D Student Enrolment System");
        System.out.println("Note: our system is not case sensitive");
        System.out.println("Option:");
        System.out.println("(A) Create");
        System.out.println("(B) Read");
        System.out.println("(C) Update");
        System.out.println("(D) Delete");
        System.out.println("(E) Exit");
    }

    public static void firstName() {
        Scanner scanner = new Scanner(System.in);

        while (start == 1) {
            System.out.println("Enter your first name");
            String first_name_input = scanner.nextLine();

            if (Pattern.compile(invalid_name_character).matcher(first_name_input).find()) {
                System.out.println("Only alphanumeric characters are allowed, numbers are not allowed");
                exception();
            } else if (first_name_input.equals("")) {
                System.out.println("Empty input detected");
                exception();
            } else {
                try {
                    FileWriter database = new FileWriter("first_name_database.txt", true);
                    database.write(first_name_input + "\n");
                    database.close();
                    System.out.println("You added successfully");
                } catch (IOException e) {
                    e.printStackTrace();
                }
                break;
            }
        }
    }

    // Implement the other input methods similarly

    public static void mainCreateFunction() {
        int max_limit = 10;
        int current_size = 0;

        try {
            BufferedReader readDatabase = new BufferedReader(new FileReader("first_name_database.txt"));
            String line;
            while ((line = readDatabase.readLine()) != null) {
                current_size++;
            }
            readDatabase.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("Database storage limit is " + max_limit);
        System.out.println("Current storage size: " + current_size);

        while (current_size < max_limit) {
            firstName();
            // Call other input methods here
            current_size++;
        }

        String invalid_back_option = "[^0]";

        Scanner scanner = new Scanner(System.in);
        while (start == 1) {
            System.out.println("Press (0) exit");
            String input_back = scanner.nextLine();
            if (Pattern.compile(invalid_back_option).matcher(input_back).find()) {
                System.out.println("Invalid Option!");
                exception();
            } else if (input_back.equals("")) {
                System.out.println("Empty input detected!");
                exception();
            } else if (input_back.equals("0")) {
                System.out.println("Exit");
                System.exit(1);
            }
        }
    }


}
